package com.demo.neo4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Neo4jDemo {

	public static void main(String[] args) {
		SpringApplication.run(Neo4jDemo.class, args);
	}

}
