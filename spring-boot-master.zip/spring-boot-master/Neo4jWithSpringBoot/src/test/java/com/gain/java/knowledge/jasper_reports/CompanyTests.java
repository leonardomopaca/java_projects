package com.gain.java.knowledge.jasper_reports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyTests {

	@Test
	void contextLoads() {
	}

}
