package com.example.demoe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoeApplicationTests {

	@Test
	void contextLoads() {
	}

}
