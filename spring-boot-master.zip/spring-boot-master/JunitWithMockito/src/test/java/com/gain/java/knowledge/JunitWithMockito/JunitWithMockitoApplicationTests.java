package com.gain.java.knowledge.JunitWithMockito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunitWithMockitoApplicationTests {

	@Test
	void contextLoads() {
	}

}
