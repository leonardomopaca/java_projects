package com.gain.java.knowledge.JunitWithMockito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunitWithMockitoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JunitWithMockitoApplication.class, args);
	}

}
