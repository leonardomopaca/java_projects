package com.energybox.backendcodingchallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendCodingChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
