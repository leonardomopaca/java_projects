package com.leospr.mypicscontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MypicscontrolApplication {

	public static void main(String[] args) {
		SpringApplication.run(MypicscontrolApplication.class, args);
	}

}
