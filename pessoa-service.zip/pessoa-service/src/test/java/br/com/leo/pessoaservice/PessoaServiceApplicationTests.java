package br.com.leo.pessoaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
