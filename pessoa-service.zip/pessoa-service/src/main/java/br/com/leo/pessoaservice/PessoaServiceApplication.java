package br.com.leo.pessoaservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PessoaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PessoaServiceApplication.class, args);
	}

}
