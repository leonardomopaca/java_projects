package com.leo.springcloudmysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
