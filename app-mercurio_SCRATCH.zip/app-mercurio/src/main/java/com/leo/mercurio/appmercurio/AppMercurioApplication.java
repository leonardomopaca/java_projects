package com.leo.mercurio.appmercurio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppMercurioApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppMercurioApplication.class, args);
	}

}
