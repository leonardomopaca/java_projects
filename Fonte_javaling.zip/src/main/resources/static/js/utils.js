// utils
const trace = (content) => console.log(content)
const $ = (element) => document.querySelectorAll(element)[0]
const toDegree = 180 / Math.PI
const toRad = Math.PI / 180

let mouse = new Vector(window.innerWidth * 0.5, window.innerHeight * 0.5)
let isMouseDown = false
let mousePressed = false

window.addEventListener('mousedown', (e) => {
    mouse.x = e.clientX
    mouse.y = e.clientY
    isMouseDown = true
    mousePressed = true
    setTimeout(() => {
        mousePressed = false
    }, 30)
})

window.addEventListener('mouseup', (e) => {
    isMouseDown = false
})

window.addEventListener('mousemove', (e) => {
    mouse.x = e.clientX
    mouse.y = e.clientY
})

window.addEventListener('touchstart', (e) => {
    mouse.x = e.touches[0].clientX
    mouse.y = e.touches[0].clientY
    isMouseDown = true
})

window.addEventListener('touchmove', (e) => {
    mouse.x = e.touches[0].clientX
    mouse.y = e.touches[0].clientY
})

window.addEventListener('touchend', (e) => {
    mousePressed = true
    setTimeout(() => {
        mousePressed = false
    }, 30)
    isMouseDown = false
})