class Loop {

    /**
     * Loop
     * 
     * @param {string} canvasID 
     * @param {number} FPS 
     * @param {number} width 
     * @param {number} height 
     */
    constructor(canvasID, FPS = 60, width = 400, height = 400) {

        // elemento canvas em que será renderizado
        this.canvas = $(canvasID)
        // define o tamanho do canvas
        this.canvas.width = width
        this.canvas.height = height
        // cria o context para desenhar
        this.graphics = this.canvas.getContext('2d')

        this.FPS = 1000 / FPS
        this.lastFrameTime = 0
        this.accumulator = 0

        const loop = (frameTime) => {

            // calcula o tempo entre o frame atual e o frame anterior
            let deltaTime = frameTime - this.lastFrameTime
            // atualiza o frame anterior para o atual
            this.lastFrameTime = frameTime
            // acumula o delta
            this.accumulator += deltaTime

            // enquanto o tempo acumulado for maior que o fps que definimos
            while (this.accumulator >= this.FPS) {

                // executa uma simulação passando o fps fixo (sempre vai passar 16.6 (60 fps))
                this.simulate(this.FPS)
                // remove do tempo acumulado a porção de fps que definimos (16.6 (60 fps))
                this.accumulator -= this.FPS

                // se nesse momento o tempo acumulado for menos que o fps
                // que definimos, ele continua e renderiza

            }

            // limpa o canvas
            this.graphics.clearRect(0, 0, this.canvas.width, this.canvas.height)

            // executa o render
            this.render(this.graphics)

            // repete o loop
            requestAnimationFrame(loop)
        }

        // executa o loop a primeira vez
        requestAnimationFrame(loop)

    }

    // implementar na instância
    simulate(dt) { }

    // implementar na instância
    render(graphics) { }

}