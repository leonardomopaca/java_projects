class Asteroid extends Triangle {

    constructor(position = new Vector, size = 20, distanceToMoon = 0) {
        super(position, size)

        this.acceleration = new Vector(0, 0)
        this.velocity = new Vector(0, 0)
        this.acceleration = new Vector(0, 0)
        this.distanceToMoon = distanceToMoon
    }

    applyForce(f = new Vector) {
        this.acceleration.add(f)
    }

    update(dt) {
        this.velocity.add(this.acceleration.x * dt, this.acceleration.y * dt)
        this.position.add(this.velocity.x * dt, this.velocity.y * dt)
        this.acceleration.update(0, 0)
    }

    draw(graphics) {
        let moonDistance = 384400;

        let km = moonDistance * (this.position.y / this.distanceToMoon);

        let text = parseFloat(km).toFixed(0) + " KM";

        graphics.fillStyle = "#FFD866";
        graphics.font = "12px 'Press Start'";
        graphics.fillText(text, this.position.x - (text.length / 2 * 11),
            this.position.y - 10);


        graphics.fillStyle = this.fillColor
        graphics.strokeStyle = this.lineColor

        graphics.beginPath()
        this.points.map((point) => {
            graphics.lineTo(this.position.x + point.x, this.position.y + point.y)
        })
        graphics.closePath()

        graphics.stroke()
        graphics.fill()
    }
}
