class Vector {

    constructor(x = 0, y = 0) {
        this.x = x
        this.y = y
    }

    clone() {
        return new Vector(this.x, this.y)
    }

    update(v) {
        if (arguments.length > 1) {
            this.x = arguments[0]
            this.y = arguments[1]
        } else {
            this.x = v.x
            this.y = v.y
        }

        return this
    }

    add(v) {

        if (arguments.length > 1) {
            this.x += arguments[0]
            this.y += arguments[1]
        } else {
            this.x += v.x
            this.y += v.y
        }

        return this
    }

    addScalar(s) {
        this.x += s
        this.y += s
        return this
    }

    subtract(v) {

        if (arguments.length > 1) {
            this.x -= arguments[0]
            this.y -= arguments[1]
        } else {
            this.x -= v.x
            this.y -= v.y
        }

        return this
    }

    subtractScalar(s) {
        this.x += s
        this.y += s
        return this
    }

    multiply(v) {

        if (arguments.length > 1) {
            this.x *= arguments[0]
            this.y *= arguments[1]
        } else {
            this.x *= v.x
            this.y *= v.y
        }

        return this
    }

    multiplyScalar(s) {
        this.x *= s
        this.y *= s
        return this
    }

    get normalize() {
        let length = this.length
        this.x /= length
        this.y /= length
        return this
    }

    get length() {
        return Math.sqrt(this.x * this.x + this.y * this.y)
    }

    get lengthSquared() {
        return this.x * this.x + this.y * this.y
    }

    get angle() {

        let angle = -Math.atan2(this.y, this.x) * toDegree

        angle = angle < 0 ? angle + 360 : angle

        return Math.abs(angle)

    }

}