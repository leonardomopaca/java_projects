class Polygon {

    constructor(points = [], position = new Vector) {

        this.fillColor = 'transparent'
        this.lineColor = 'white'

        // posição
        this.position = position

        // os pontos (vetores) que definem o shape do polígono
        this.points = this.originalPoints = points

        // read only
        this.angle = 0

    }

    scale(size) {

        this.points.map((point) => {
            point.normalize.multiplyScalar(size)
        })

    }

    /**
     * Rotaciona o polígono no eixo Z ao redor de um ponto do polígono x, y
     *
     * @param {number} angle
     * @param {number} x
     * @param {number} y
     */
    rotate(angle, x = 0, y = 0.25) {

        // cosseno do ângulo que irá rotacionar
        let cos = Math.cos(angle * toRad)
        // seno do ângulo que irá rotacionar
        let sin = Math.sin(angle * toRad)

        // array com os novos pontos
        let points = []

        // itera sob os pontos originais do polígono
        this.originalPoints.map((point) => {

            // clona o ponto original
            let p = point.clone()

            // rotaciona o ponto
            let px = (p.x - x) * cos - (p.y - y) * sin
            let py = (p.x - x) * sin + (p.y - y) * cos

            // guarda o ponto rotacionado no array temporário
            points.push(new Vector(px, py))

        })

        // atualiza os pontos do polígono - os originais são mantidos intactos
        this.points = points

        // atualiza o ângulo do polígono - read only
        this.angle = angle

    }

    draw(graphics) {

    }
}
