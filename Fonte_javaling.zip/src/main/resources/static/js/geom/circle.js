class Circle {

    constructor(position = new Vector, radius = 25, label = "") {

        this.position = position

        this.radius = radius

        this.label = label

    }

    draw(graphics) {
        graphics.fillStyle = this.fillColor
        graphics.strokeStyle = this.lineColor

        graphics.beginPath()
        graphics.arc(this.position.x, this.position.y, this.radius, 0, 2 * Math.PI)
        graphics.closePath()
        graphics.stroke()
        graphics.fill()

        if (this.label) {
            graphics.fillStyle = "#ffd866";
            graphics.font = "12px 'Press Start'";
            graphics.fillText(this.label, this.position.x - (this.label.length / 2 * 11),
                this.position.y + 50);
        }
    }

}
