class Triangle extends Polygon {

    constructor(position, size) {
        super([
            new Vector(-0.5, 0.5),
            new Vector(-0.5, -0.5),
            new Vector(0.5, 0.025),
        ], position)

        this.scale(size)

    }

}