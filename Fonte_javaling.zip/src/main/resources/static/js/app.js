let xmlhttp = new XMLHttpRequest();
let url = "http://localhost:8080/asteroids";

xmlhttp.onreadystatechange = function () {
    if (this.readyState === 4 && this.status === 200) {
        let data = JSON.parse(this.responseText);
        main(data);
    }
};

xmlhttp.open("GET", url, true);
xmlhttp.send();

function main(data) {
    let asteroids = [];

    data.close_approach_data.map(close_approach_data => {
        let year = new Date(close_approach_data.epoch_date_close_approach);

        let lunarDistance = close_approach_data.miss_distance.lunar;

        asteroids[year.getFullYear()] = lunarDistance;
    });

    let loop = new Loop('#stage', 60, window.innerWidth, window.innerHeight);

    let points = [];

    let earths = [];

    let moons = [];

    let distanceFromTop = 50;

    let moonDistanceFromEarth = 400;

    let index = 0;

    let length = Object.keys(asteroids).length;

    asteroids.map((distance, year) => {
        let x = ((window.innerWidth / length) * index) + (window.innerWidth / length / 2);
        let y = distanceFromTop;

        let earth = new Circle(new Vector(x, y), 25);
        earth.fillColor = "#66D9EF";
        earth.lineColor = "#66D9EF";
        earths.push(earth);

        let moon = new Circle(new Vector(x, y + earth.radius + moonDistanceFromEarth), 6, "ANO " + year);
        moon.fillColor = "white";
        moon.lineColor = "white";
        moons.push(moon);

        let point = new Circle(new Vector(x, y + earth.radius + (moonDistanceFromEarth * distance)), 2);
        point.fillColor = "grey";
        point.lineColor = "grey";
        points.push(point);

        index++;
    });

    let asteroid = new Asteroid(new Vector(points[0].x, points[0].y), 10, 475);
    asteroid.fillColor = "#F92672";
    asteroid.lineColor = "#F92672";

    let currentPoint = 0;

    loop.simulate = (dt) => {

        asteroid.update(dt);

        let asteroidToPoint = points[currentPoint].position.clone().subtract(asteroid.position);
        let shipToPlanetDirection = asteroidToPoint.clone().normalize;
        let f = shipToPlanetDirection.multiplyScalar(.0001);
        asteroid.applyForce(f);

        if (asteroidToPoint.length < 25) {
            currentPoint = (currentPoint + 1) % points.length;

            if (currentPoint === 0) {
                points = points.reverse();
            }
        }

        asteroid.velocity.multiplyScalar(0.92);

        asteroid.rotate(-asteroidToPoint.angle);
    };


    loop.render = (graphics) => {
        asteroid.draw(graphics);

        points.map((point) => point.draw(graphics));
        earths.map((earth) => earth.draw(graphics));
        moons.map((moon) => moon.draw(graphics));
    }
}
