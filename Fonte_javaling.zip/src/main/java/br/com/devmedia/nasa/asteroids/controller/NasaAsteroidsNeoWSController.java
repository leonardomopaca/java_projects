package br.com.devmedia.nasa.asteroids.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Map;

@Controller
public class NasaAsteroidsNeoWSController {

    private final String NEOWS_URL = "https://api.nasa.gov/neo/rest/v1/neo/3799865?api_key=%s";

    private final String API_KEY = "35FZrDodeDueuJYedX0Cv4poDj30ASf3SjbjY3CM";

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/asteroids")
    @ResponseBody
    public Map<String, Object> lookupToTheStars() throws IOException {
        InputStream stream = new URL(String.format(NEOWS_URL, API_KEY)).openStream();

        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> json = mapper.readValue(stream, Map.class);

        return json;
    }
}
