package com.example.sdnmarvelbasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SdnMarvelBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
