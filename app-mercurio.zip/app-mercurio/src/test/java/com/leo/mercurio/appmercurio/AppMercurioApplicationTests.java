package com.leo.mercurio.appmercurio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppMercurioApplicationTests {

	@Test
	void contextLoads() {
	}

}
